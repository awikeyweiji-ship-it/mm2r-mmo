import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';

class AppConfig extends ChangeNotifier {
  String? baseUrl;
  String healthStatus = 'Unknown';
  String wsStatus = 'Disconnected';
  String lastHealthUrl = '';
  String lastWsUrl = '';
  String lastWsError = ''; // Added to store detailed error
  String browserOrigin = Uri.base.origin;
  
  WebSocketChannel? ws;
  String? playerId;
  int playerCount = 0; // Added for UI display
  
  // Stream controller to broadcast game state updates to UI
  final _gameStateController = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get gameStateStream => _gameStateController.stream;

  Future<void> discoverBackend() async {
    final Uri currentUri = Uri.base;
    String detectedBaseUrl;

    if (currentUri.host.endsWith('.app.goog')) {
      detectedBaseUrl = 'https://${currentUri.host}:8080';
    } else {
      detectedBaseUrl = 'http://localhost:8080';
    }
    
    // Allow overriding via query param for testing if needed, though relying on Uri.base is better for IDX
    if (currentUri.queryParameters.containsKey('backend')) {
        detectedBaseUrl = currentUri.queryParameters['backend']!;
    }

    baseUrl = detectedBaseUrl;
    notifyListeners();

    await _checkHealth();
    await _connectWs();
  }

  static String deriveWsUrl(String httpBaseUrl) {
      if (httpBaseUrl.startsWith('https://')) {
          return httpBaseUrl.replaceFirst('https://', 'wss://').replaceFirst(RegExp(r'/$'), '');
      } else {
          return httpBaseUrl.replaceFirst('http://', 'ws://').replaceFirst(RegExp(r'/$'), '');
      }
  }

  Future<void> _checkHealth() async {
    if (baseUrl == null) return;
    lastHealthUrl = '$baseUrl/health';
    try {
      final response = await http.get(Uri.parse(lastHealthUrl));
      if (response.statusCode == 200) {
        healthStatus = 'OK';
      } else {
        healthStatus = 'Error: ${response.statusCode}';
      }
    } catch (e) {
      healthStatus = 'Exception: ${e.toString()}';
    }
    notifyListeners();
  }

  Future<void> _connectWs() async {
    if (baseUrl == null) return;
    
    // Correct WS URL derivation
    String wsBase = deriveWsUrl(baseUrl!);
    lastWsUrl = '$wsBase?roomId=poc_world&name=player-${DateTime.now().millisecondsSinceEpoch % 1000}';

    try {
      if (ws != null) {
          ws!.sink.close();
      }
      ws = WebSocketChannel.connect(Uri.parse(lastWsUrl));
      wsStatus = 'Connecting';
      notifyListeners();

      ws!.stream.listen(
        (message) {
            try {
                if (wsStatus != 'Connected') {
                    wsStatus = 'Connected';
                    lastWsError = ''; // Clear error on success
                    notifyListeners();
                }
                
                final data = jsonDecode(message);
                
                if (data['type'] == 'welcome') {
                    playerId = data['playerId'];
                    notifyListeners();
                } else if (data['type'] == 'snapshot') {
                    final players = data['players'] as Map<String, dynamic>;
                    playerCount = players.length;
                    _gameStateController.add(data);
                    notifyListeners(); // Update player count UI
                } else if (data['type'] == 'state' || data['type'] == 'delta') {
                    _gameStateController.add(data);
                    if (data['type'] == 'delta') {
                         // Rudimentary count update if needed, but snapshot is authoritative
                         if (data['removes'] != null || data['upserts'] != null) {
                             // ideally we track full state in AppConfig or delegate to UI. 
                             // For debug display, we can just wait for next snapshot or track locally.
                         }
                    }
                }
            } catch (e) {
                print('Error parsing WS message: $e');
            }
        },
        onDone: () {
          wsStatus = 'Disconnected';
          notifyListeners();
        },
        onError: (error) {
          wsStatus = 'Error';
          lastWsError = error.toString();
          notifyListeners();
        },
      );
    } catch (e) {
      wsStatus = 'Exception';
      lastWsError = e.toString();
      notifyListeners();
    }
  }

  void sendWsMessage(String message) {
      ws?.sink.add(message);
  }
  
  void retryConnection() {
      _connectWs();
  }

  @override
  void dispose() {
    _gameStateController.close();
    ws?.sink.close();
    super.dispose();
  }
}
