import 'dart:convert';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'app_config.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => AppConfig(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter World MMO',
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      home: const WorldScreen(),
    );
  }
}

class WorldScreen extends StatefulWidget {
  const WorldScreen({super.key});

  @override
  State<WorldScreen> createState() => _WorldScreenState();
}

class Player {
  final String id;
  final String name;
  final Color color;
  
  // Interpolation state
  Point<double> lastPosition;
  Point<double> targetPosition;
  double lastServerUpdate; // Timestamp of the last update received

  Player({
    required this.id,
    required this.name,
    required this.color,
    required Point<double> position,
  }) : lastPosition = position,
       targetPosition = position,
       lastServerUpdate = DateTime.now().millisecondsSinceEpoch.toDouble();

  // Called when a new state arrives from server
  void updateTarget(Point<double> newPosition, double timestamp) {
    // Current visual position becomes the start of the next interpolation
    lastPosition = getLerpPosition(DateTime.now().millisecondsSinceEpoch.toDouble());
    targetPosition = newPosition;
    lastServerUpdate = DateTime.now().millisecondsSinceEpoch.toDouble();
  }

  // Calculate current interpolated position
  Point<double> getLerpPosition(double now) {
    // We expect updates roughly every 100ms (10Hz). 
    // We add a small buffer (e.g. 1.5x) to smooth out network jitter.
    const serverUpdateInterval = 100.0; 
    
    double timeSinceUpdate = now - lastServerUpdate;
    double t = (timeSinceUpdate / serverUpdateInterval).clamp(0.0, 1.0);
    
    // Simple Linear Interpolation
    return Point(
      ui.lerpDouble(lastPosition.x, targetPosition.x, t)!,
      ui.lerpDouble(lastPosition.y, targetPosition.y, t)!,
    );
  }
}

class _WorldScreenState extends State<WorldScreen> with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  
  // Local Player
  Point<double> _localPos = const Point(200.0, 200.0);
  
  // Remote Players
  final Map<String, Player> _remotePlayers = {};
  
  @override
  void initState() {
    super.initState();
    // Animation loop for smooth rendering (60fps)
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat();
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final config = Provider.of<AppConfig>(context, listen: false);
      config.discoverBackend();
      config.addListener(_onAppConfigChange);
      
      // Keyboard input support for Web/Desktop
      ServicesBinding.instance.keyboard.addHandler(_onKey);
    });
  }

  bool _onKey(KeyEvent event) {
    if (event is KeyDownEvent) {
      double dx = 0;
      double dy = 0;
      const step = 10.0;
      
      if (event.logicalKey == LogicalKeyboardKey.arrowUp) dy = -step;
      if (event.logicalKey == LogicalKeyboardKey.arrowDown) dy = step;
      if (event.logicalKey == LogicalKeyboardKey.arrowLeft) dx = -step;
      if (event.logicalKey == LogicalKeyboardKey.arrowRight) dx = step;
      
      if (dx != 0 || dy != 0) {
        _moveLocalPlayer(_localPos.x + dx, _localPos.y + dy);
        return true;
      }
    }
    return false;
  }
  
  void _moveLocalPlayer(double x, double y) {
      setState(() {
          _localPos = Point(x, y);
      });
      
      // Send to server
      final config = Provider.of<AppConfig>(context, listen: false);
      if (config.wsStatus == 'Connected') {
          config.sendWsMessage(jsonEncode({
              'type': 'move',
              'x': x,
              'y': y
          }));
      }
  }

  void _onAppConfigChange() {
    final config = Provider.of<AppConfig>(context, listen: false);
    
    // Listen to WS stream if connected and not already listening
    if (config.wsStatus == 'Connected' && config.ws != null) {
      // Note: In a real app, manage subscription carefully to avoid duplicates.
      // Here we rely on AppConfig to only notify once or check status.
      // But AppConfig exposes the stream. We need a way to hook only once.
      // Better: AppConfig handles the listen and exposes a stream of parsed messages or just notifies.
      // For this POC, we'll hook directly here but we need to be careful not to re-hook.
      // Actually, let's just poll the stream in AppConfig or have AppConfig callback us?
      // A simpler way for this POC: AppConfig exposes a 'lastState' or we just re-listen (Stream is single-sub usually).
      // Let's assume AppConfig is safe to access 'ws.stream' repeatedly? No, it's a single subscription.
      // Fix: We move the stream listening into this widget, or better, make AppConfig broadcast stream.
      // BUT, for now, let's just check if we have already set up a listener? No easy way.
      // Let's modify AppConfig to be a BroadcastStream or handle the logic there.
      // Actually, looking at previous AppConfig, it was listening inside itself? No.
      // It was: ws!.stream.listen(...) inside connectWs. 
      // Wait, the previous AppConfig consumed the stream to update status. 
      // That means we CANNOT listen to it again here.
      // Correct approach: AppConfig should expose a StreamController that broadcasts state updates.
    }
  }
  
  @override
  void dispose() {
    ServicesBinding.instance.keyboard.removeHandler(_onKey);
    final config = Provider.of<AppConfig>(context, listen: false);
    config.removeListener(_onAppConfigChange);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Poll for updates from AppConfig (since AppConfig consumes the WS stream)
    // We need to change AppConfig to expose the state, OR we change AppConfig to Broadcast.
    // Let's check AppConfig again.
    // It consumes stream to check 'welcome'. It does NOT expose the stream for other messages.
    // We MUST modify AppConfig to broadcast messages to us.
    
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        title: const Text('World MMO'),
        backgroundColor: Colors.grey[850],
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60.0),
          child: Container(
            color: Colors.black26,
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Consumer<AppConfig>(
              builder: (context, config, child) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                            Text('Status: ${config.wsStatus}', style: TextStyle(color: config.wsStatus == 'Connected' ? Colors.green : Colors.red)),
                            Text('ID: ${config.playerId ?? "..."}', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                        ]
                    ),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                            Text('Backend: ${config.baseUrl ?? "Locating..."}', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                            Text('Origin: ${config.browserOrigin}', style: const TextStyle(fontSize: 10, color: Colors.white54)),
                        ]
                    )
                  ],
                );
              },
            ),
          ),
        ),
      ),
      body: GestureDetector(
        onPanUpdate: (details) {
            _moveLocalPlayer(_localPos.x + details.delta.dx, _localPos.y + details.delta.dy);
        },
        child: Consumer<AppConfig>(
            builder: (context, config, child) {
                // HACK: Poll or use a callback mechanism.
                // Since we can't easily change AppConfig's stream consumption without breaking its internal logic logic easily,
                // let's rely on AppConfig to notify us of state changes if we add a 'lastState' field.
                
                // Better yet, let's pass a callback to AppConfig or listen to a Stream it provides.
                // We will update AppConfig in the next step to support this.
                // For now, assume AppConfig has `gameStateStream`.
                
                return StreamBuilder<Map<String, dynamic>>(
                    stream: config.gameStateStream,
                    builder: (context, snapshot) {
                        if (snapshot.hasData) {
                             final players = snapshot.data!['players'] as Map<String, dynamic>;
                             final now = DateTime.now().millisecondsSinceEpoch.toDouble();
                             
                             // Update remote players
                             players.forEach((id, playerData) {
                                if (id == config.playerId) return; // Skip self (handled locally)
                                
                                final targetPos = Point(
                                    (playerData['x'] as num).toDouble(),
                                    (playerData['y'] as num).toDouble()
                                );
                                
                                if (_remotePlayers.containsKey(id)) {
                                    _remotePlayers[id]!.updateTarget(targetPos, now);
                                } else {
                                    _remotePlayers[id] = Player(
                                        id: id,
                                        name: playerData['name'] ?? 'Unknown',
                                        color: Color(int.parse((playerData['color'] as String).substring(1), radix: 16) + 0xFF000000),
                                        position: targetPos,
                                    );
                                }
                             });
                             
                             // Remove disconnected
                             _remotePlayers.removeWhere((id, _) => !players.containsKey(id));
                        }
                        
                        return AnimatedBuilder(
                            animation: _controller!,
                            builder: (context, child) {
                                final now = DateTime.now().millisecondsSinceEpoch.toDouble();
                                return CustomPaint(
                                    painter: WorldPainter(
                                        localPos: _localPos,
                                        remotePlayers: _remotePlayers.values.toList(),
                                        now: now,
                                        myId: config.playerId
                                    ),
                                    size: Size.infinite,
                                );
                            }
                        );
                    }
                );
            }
        ),
      ),
    );
  }
}

class WorldPainter extends CustomPainter {
  final Point<double> localPos;
  final List<Player> remotePlayers;
  final double now;
  final String? myId;

  WorldPainter({
      required this.localPos, 
      required this.remotePlayers, 
      required this.now,
      this.myId
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Background grid
    final gridPaint = Paint()..color = Colors.white10..strokeWidth = 1;
    for (double i = 0; i < size.width; i += 50) {
        canvas.drawLine(Offset(i, 0), Offset(i, size.height), gridPaint);
    }
    for (double i = 0; i < size.height; i += 50) {
        canvas.drawLine(Offset(0, i), Offset(size.width, i), gridPaint);
    }

    // Draw Remote Players
    for (final player in remotePlayers) {
      _drawPlayer(canvas, player.getLerpPosition(now), player.color, player.name);
    }

    // Draw Self
    _drawPlayer(canvas, localPos, Colors.blue, "Me (${myId?.substring(0, 4) ?? '?'})");
  }

  void _drawPlayer(Canvas canvas, Point<double> pos, Color color, String name) {
      final paint = Paint()..color = color;
      
      // Shadow
      canvas.drawCircle(Offset(pos.x, pos.y + 5), 15, Paint()..color = Colors.black26..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
      
      // Body
      canvas.drawRect(Rect.fromCenter(center: Offset(pos.x, pos.y), width: 30, height: 30), paint);
      
      // Border
      canvas.drawRect(Rect.fromCenter(center: Offset(pos.x, pos.y), width: 30, height: 30), Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 2);

      // Name Tag
      final textSpan = TextSpan(
        text: name,
        style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold, shadows: [Shadow(offset: Offset(1,1), blurRadius: 2, color: Colors.black)]),
      );
      final textPainter = TextPainter(text: textSpan, textDirection: TextDirection.ltr);
      textPainter.layout();
      textPainter.paint(canvas, Offset(pos.x - textPainter.width / 2, pos.y - 35));
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
