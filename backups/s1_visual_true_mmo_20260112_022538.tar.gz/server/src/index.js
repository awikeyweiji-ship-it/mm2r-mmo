const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors({ origin: true }));
app.options('*', cors());

app.get('/health', (req, res) => {
  res.status(200).json({ ok: true, timestamp: new Date().toISOString() });
});

const rooms = {};
const TICK_RATE = 10; // 10Hz (100ms) - consistent with "minimal view" req (10~15Hz)
const MOVE_THROTTLE_MS = 50;

// Log broadcast stats
let broadcastCounts = {};
setInterval(() => {
    // Only log if there is activity
    const activeRooms = Object.keys(broadcastCounts);
    if (activeRooms.length > 0) {
        console.log('--- Broadcast Stats (Last 10s) ---');
        for (const roomId of activeRooms) {
            const count = broadcastCounts[roomId];
            const rate = count / 10;
            console.log(`[Metrics] Room '${roomId}' broadcast rate: ${rate.toFixed(1)} Hz`);
        }
        broadcastCounts = {}; // Reset
    }
}, 10000);

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const roomId = url.searchParams.get('roomId') || 'poc_world';
  const nameParam = url.searchParams.get('name');
  
  // Robust ID generation
  const randId = Math.random().toString(36).substr(2, 6);
  const playerId = `${nameParam || 'player'}-${randId}`;
  const playerName = nameParam || `Player ${randId}`;
  
  // Random color for visual distinction
  const playerColor = `#${Math.floor(Math.random()*16777215).toString(16).padStart(6, '0')}`;

  ws.roomId = roomId;
  ws.playerId = playerId;

  if (!rooms[roomId]) {
    rooms[roomId] = {
      players: {},
      tickInterval: null,
      lastBroadcast: 0
    };
    // Initialize stats for this room
    if (!broadcastCounts[roomId]) broadcastCounts[roomId] = 0;
    
    console.log(`Created room: ${roomId}`);
    
    // Start Ticking
    rooms[roomId].tickInterval = setInterval(() => {
        tickRoom(roomId);
    }, 1000 / TICK_RATE);
  }

  const room = rooms[roomId];
  const lastMove = { time: 0 };
  
  // Initialize player in room
  room.players[playerId] = {
    id: playerId,
    name: playerName,
    color: playerColor,
    x: Math.random() * 300 + 50, // Random start pos
    y: Math.random() * 300 + 50,
    ts: Date.now(),
  };

  // Send welcome message
  ws.send(JSON.stringify({ 
      type: 'welcome', 
      playerId, 
      config: { tickRate: TICK_RATE },
      roomState: room.players 
  }));

  ws.on('message', (message) => {
    try {
      const now = Date.now();
      // Throttle incoming moves
      if (now - lastMove.time < MOVE_THROTTLE_MS) return;

      const data = JSON.parse(message);
      
      if (data.type === 'move') {
        const player = room.players[playerId];
        if (player) {
            // Update state
            player.x = data.x;
            player.y = data.y;
            player.ts = now;
            lastMove.time = now;
        }
      }
    } catch (e) {
      console.error('Failed to parse message:', e);
    }
  });

  ws.on('close', () => {
    if (rooms[roomId] && rooms[roomId].players[playerId]) {
        delete rooms[roomId].players[playerId];
        console.log(`Player ${playerId} left room ${roomId}.`);
        
        // If room empty, cleanup
        if (Object.keys(rooms[roomId].players).length === 0) {
            clearInterval(rooms[roomId].tickInterval);
            delete rooms[roomId];
            console.log(`Room ${roomId} destroyed.`);
        }
    }
  });
});

function tickRoom(roomId) {
  const room = rooms[roomId];
  if (!room) return;

  // Broadcast state
  const state = { type: 'state', players: room.players, ts: Date.now() };
  const message = JSON.stringify(state);
  
  // Update stats
  if (!broadcastCounts[roomId]) broadcastCounts[roomId] = 0;
  broadcastCounts[roomId]++;

  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN && client.roomId === roomId) {
      client.send(message, (error) => {
        if (error) {
          // console.error('Send error:', error); // Silence minor errors
        }
      });
    }
  });
}

const HOST = process.env.HOST || '0.0.0.0';
const PORT = process.env.PORT || 8080;

server.listen(PORT, HOST, () => {
  console.log(`Server is listening on ${HOST}:${PORT}`);
});
